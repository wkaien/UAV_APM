To setup the project and program an ATMEG32U2 with the Arduino USB DFU bootloader:


> make clean
> make
> make program



Check that the board enumerates as "Atmega32u2".
Test by uploading the Arduino-usbserial application firmware (see instructions in Arduino-usbserial directory)

